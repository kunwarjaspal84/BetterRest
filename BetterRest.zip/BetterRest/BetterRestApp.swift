//
//  BetterRestApp.swift
//  BetterRest
//
//  Created by Kunwardeep Singh on 2021-06-03.
//

import SwiftUI

@main
struct BetterRestApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
